﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace ADO_ConnectedArchi
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        public Form1()
        {
            InitializeComponent();
            sqlcon = new SqlConnection("server=172.16.96.168; initial catalog=xCarrier; user id=sa; password=WeaVer234;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon.Open();

                //for (int i = 0; i < 10; i++)
                //{
                    SqlCommand sqlcmd = new SqlCommand("INSERT INTO STUDENT_INFO (ID,NAME,AGE,CLASS,SECTION) VALUES('"+ textid.Text +"','"+ textname.Text +"','"+ textage.Text +"','"+ textclass.Text+"','"+ textsection.Text +"')", sqlcon);
                    sqlcmd.ExecuteNonQuery();
                //}

                

              //  MessageBox.Show("Connection Success!");
                sqlcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
           
        }
    }
}
