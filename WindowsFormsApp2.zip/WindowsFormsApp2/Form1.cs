﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Configuration;

namespace WindowsFormsApp2
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        SqlCommand sqlcmd;
        SqlDataReader sqldr;
        public Form1()
        {
            InitializeComponent();
            sqlcon = new SqlConnection("server=172.16.96.168; initial catalog=xCarrier; user id=sa; password=WeaVer234;");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon.Open();
                // MessageBox.Show("Connection Success!");
                //string[,] arr = new string[3, 5] { {"10", "Raghu", "17","12","B" },{ "10", "Raghu", "17", "12", "C" },{ "10", "Raghu", "17", "12", "D" } } ;

                //for (int i = 0; i < 3; i++)
                //{
                //    for (int j = 0; j < 4; j++)
                //    {
                //        SqlCommand sqlcmd = new SqlCommand("insert into Student_Info(StudentID,Name,Age,Class,Section) Values(" + i + ","+ j[0] +",'16','8','A')", sqlcon);
                //        sqlcmd.ExecuteNonQuery();
                //    }
                //}

                for (int i = 0; i < 10; i++)
                {
                    sqlcmd = new SqlCommand("insert into Student_Info(StudentID,Name,Age,Class,Section) Values(" + i + ",'Kumar','16','8','A')", sqlcon);
                    sqlcmd.ExecuteNonQuery();
                }

                sqlcon.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            sqlcon.Open();
            sqlcmd = new SqlCommand("SELECT * FROM Student_Info", sqlcon);
            sqldr = sqlcmd.ExecuteReader();
            DataTable dt = new DataTable();
           
            dt.Load(sqldr);
            dataGridView1.DataSource = dt;  
            sqlcon.Close();
           // dataGridView1.;
        }
    }
}
