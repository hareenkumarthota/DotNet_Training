﻿using System;

namespace FirstProgram
{
    class Program
    {
        static void Main(string[] args)
        {
            // Print 1 to 100 numbers
            //for (int i = 1; i <= 100; i++)
            //{
            //    Console.WriteLine("Numbers: " + i);
            //}

            // Print 100 to 1 numbers
            //for (int i = 100; i >= 1; i--)
            //{
            //    Console.WriteLine("Numbers: " + i);
            //}
            // Print Prime Numbers

            bool isprime = true;
            int i, j;
            for (i = 2; i <= 100; i++)
            {
                for (j = 2; j <= 100; j++)
                {
                    if (i != j && i % j == 0)
                    {
                        isprime = false;
                        break;
                    }
                }
                if (isprime)
                {
                    Console.WriteLine("Prime Number: " + i);
                }
                isprime = true;
            }

            // Print the Tables 

            for (int k = 2; k <= 20; k++)
            {
                for (int l = 2; l <= 10; l++)
                {
                    Console.WriteLine("{0}*{1}={2}", k, l, k * l);  //2 * 2 = 4 
                }
            }

            Console.ReadLine();
            //Console.WriteLine("Hello World!");
        }
    }
}
