﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection sqlcon;
        SqlDataAdapter sqlda;
        SqlDataReader sqldr;
        DataSet ds;

        //SELECT * FROM ABC;SELECT * FROM XYZ;SELECT * FROM XVB
        public Form1()
        {
            InitializeComponent();
            sqlcon = new SqlConnection("server=172.16.96.168; initial catalog=xCarrier; user id=sa; password=WeaVer234;");
            BindData();
        }

        public void BindData()
        {
            sqlda = new SqlDataAdapter("SELECT * FROM INFORMATION", sqlcon);
            ds = new DataSet();
            sqlda.Fill(ds);
            //DataTable dt = new DataTable();
            //dt.Load(ds);
           // dataGridView1.AutoGenerateColumns = false;
           
            dataGridView1.DataSource = ds.Tables[0];

          //  Edit Button
            DataGridViewButtonColumn editcolumn = new DataGridViewButtonColumn();
            editcolumn.FlatStyle = FlatStyle.Popup;
            editcolumn.HeaderText = "Edit";
            editcolumn.Name = "Edit";
            editcolumn.UseColumnTextForButtonValue = true;
            editcolumn.Text = "Edit";
            editcolumn.Width = 60;
            if (dataGridView1.Columns.Contains(editcolumn.Name = "Edit"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(editcolumn);
            }

            // Delete Button

            DataGridViewButtonColumn deletecolumn = new DataGridViewButtonColumn();
            deletecolumn.FlatStyle = FlatStyle.Popup;
            deletecolumn.HeaderText = "Delete";
            deletecolumn.Name = "Delete";
            deletecolumn.UseColumnTextForButtonValue = true;
            deletecolumn.Text = "Delete";
            deletecolumn.Width = 60;
            if (dataGridView1.Columns.Contains(deletecolumn.Name = "Delete"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(deletecolumn);
            }

        }
       

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                sqlcon.Open();

                var insertquery = "INSERT INTO INFORMATION(NAME,AGE,COLOR,DOB,JOB,SALARY) VALUES('" + textBox1.Text + "','" + textBox2.Text + "','" + textBox3.Text + "','" + textBox4.Text + "','" + textBox5.Text + "','" + textBox6.Text + "')";

                sqlda = new SqlDataAdapter();
                sqlda.InsertCommand = new SqlCommand(insertquery,sqlcon);
                sqlda.InsertCommand.ExecuteNonQuery();
                sqlcon.Close();
                //textBox1.Text = "";
               

                if (textBox1.Text == "")
                {
                    MessageBox.Show("Please enter the Name!");
                    return;
                }

                BindData();
               



                //   richTextBox1.Text = result.ToString();
            }
            //catch(DivideByZeroException)
            //{
            //    label3.Text = "Cannot divide by Zero";
            //}
            //catch (FormatException)
            //{
            //    label3.Text = "Please enter only non decimal numbers";
            //}
            catch (Exception ex)
            {
                //label3.Text = "Please enter integer values";
                richTextBox1.Text = ex.GetType() + " : " +  ex.StackTrace +  " : " + ex.Message.ToString();
            }
            //finally
            //{
            //    label3.Text = "Divided Successfully!";
            //}
            
        }

        long id;
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 7)
            {
                id = Convert.ToInt32(dataGridView1.Rows[e.RowIndex].Cells["Column1"].Value.ToString());
                textBox1.Text = dataGridView1.Rows[e.RowIndex].Cells["Column2"].Value.ToString();
                textBox2.Text = dataGridView1.Rows[e.RowIndex].Cells[2].Value.ToString();
                textBox3.Text = dataGridView1.Rows[e.RowIndex].Cells[3].Value.ToString();
                textBox4.Text = dataGridView1.Rows[e.RowIndex].Cells[4].Value.ToString();
                textBox5.Text = dataGridView1.Rows[e.RowIndex].Cells[5].Value.ToString();
                textBox6.Text = dataGridView1.Rows[e.RowIndex].Cells[6].Value.ToString();
                Submit.Text = "Update";
            }
            else if (e.ColumnIndex == 8)
            {

            }
        }
    }
}
